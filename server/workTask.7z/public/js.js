var socket = io();

function Submit(e) {
    e.preventDefault();
    socket.emit('chat message', document.getElementById('message').val())
    document.getElementById('message').val('');
    return false;

}

socket.on('chat message', function (msg) {
    console.log(msg)
    document.getElementById('messages').append('<li>').text(msg);
});
